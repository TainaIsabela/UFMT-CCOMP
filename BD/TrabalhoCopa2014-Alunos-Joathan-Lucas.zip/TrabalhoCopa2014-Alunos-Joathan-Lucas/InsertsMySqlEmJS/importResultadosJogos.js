//Importações necessárias para ler arquivo CSV
//Comando necessários: "npm install fast-csv mysql2"
const fs = require("fs");
const mysql = require("mysql2");
const fastcsv = require("fast-csv");

//stream fica responsável pelo arquivo csv passado
//enquanto vamos armazenar os dados em csvData
//fastcsv para a análise de dados
let stream = fs.createReadStream("../dadosCSV/Resultados_jogos.csv");
let csvData = [];
let csvStream = fastcsv
  .parse()
  //Vamos tratar dois eventos a seguir o "data" e o "end"
  //Em data, vamos manipular os dados, todos dados são passados por aqui para analisar
  .on("data", function (data) {
    csvData.push(data);
  })
  //Após a análise de todos os dados, vamos jogamos no banco os dados
  .on("end", function () {

    //Criando conexão com bd
    const connection = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "ramos",
      database: "copa"
    });

    connection.connect(error => {
      if (error) {
        console.error(error);
      } else {
        let query =
          "INSERT INTO resultados_jogos (partida_id, data_jogo, hora_inicio, time1, time2, gols_time1, gols_time2, estadio, cidade_sede) VALUES ?";
        console.log([csvData]);
        connection.query(query, [csvData], (error, response) => {
           console.log(error || response);
        });
      }
    });
  });

stream.pipe(csvStream);