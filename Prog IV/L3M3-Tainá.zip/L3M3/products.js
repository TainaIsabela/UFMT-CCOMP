var products = {
  123: {
    name: "Lenovo",
    desc: "Da pro gasto",
    img: "lenovo.webp",
    price: 4000
  },
  124: {
    name: "Apple MacBook Pro",
    desc: "Coisa de rico",
    img: "macbook.jpg",
    price: 12000
  },
  125: {
    name: "Samsung",
    desc: "bateria a parte",
    img: "samsung.webp",
    price: 5000
  },
  126: {
    name: "Positivo",
    desc: "Caos e Destruicao.",
    img: "positivo.webp",
    price: 2000
  }
};