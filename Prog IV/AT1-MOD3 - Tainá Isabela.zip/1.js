let a=9;
let b=17;
let c=8; 

let soma = (a + b)/c;


c = c-b;

console.log('A:', a);
console.log('B:', b);
console.log('C:', c);