// Instituição: UFMT - Campus Araguaia
// Disciplina: Prog. II 
// Aluna: Tainá Isabela Monteiro da Silva - RGA: 202011722019


// Esta sendo criado dois ponteiros para inteiro, um para o valor 42 e outro para o valor 100.
// o ponteiro r aponta para o ponteiro q, ou seja, o valor 42 é copiado para o ponteiro r.
// o auto q2 e r2 são ponteiros para inteiro, mas são criados como shared_ptr, ou seja,
// o valor 42 é copiado para o ponteiro q2 e o valor 100 é copiado para o ponteiro r2.
// o ponteiro r2 aponta para o ponteiro q2, ou seja, o valor 42 é copiado para o ponteiro r2.
