int valor;

write "Informe um valor:";
read valor;

while (valor > 0)
begin
    write "\nvalor:";
    write valor;
    valor = valor - 1;
end