int a;
int b;
arrow c;
read a;
write a;