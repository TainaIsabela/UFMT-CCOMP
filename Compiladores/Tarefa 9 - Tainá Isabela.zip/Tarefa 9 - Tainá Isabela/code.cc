int valor;
float soma(float x, float y,);
int teste(int v,);
string frase(string fala,);

begin
    write "Informe um valor:";
    read valor;

    while (valor > 0)
    begin
        write "\nvalor:";
        write valor;
        valor = (valor + valor);
    end
    
    teste(valor,);
end
