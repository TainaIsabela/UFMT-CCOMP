int a;
int b;
int c;
float d;