float nota;
string nome;

write "Informe seu nome:";
read nome;

write "Infome sua nota:";
read nota;

write nome;
write "sua nota e: ";
write nota;