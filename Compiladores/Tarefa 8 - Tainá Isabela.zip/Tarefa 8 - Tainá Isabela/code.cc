int valor;
float soma(float x, float y,);
int soma1();

begin
    write "Informe um valor:";
    read valor;

    while (valor > 0)
    begin
        write "\nvalor:";
        write valor;
        valor = valor - 1;
    end
end
