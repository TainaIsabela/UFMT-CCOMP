package Questao1;
// interface Mensuravel
public interface Mensuravel {
    double getMedidas();
}