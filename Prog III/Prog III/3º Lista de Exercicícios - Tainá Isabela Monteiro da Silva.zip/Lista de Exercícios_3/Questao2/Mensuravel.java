package Questao2;
public interface Mensuravel {
    double getMedidas();
    double media(Mensuravel[] obj);
    public Object maior(Mensuravel[] list);
}