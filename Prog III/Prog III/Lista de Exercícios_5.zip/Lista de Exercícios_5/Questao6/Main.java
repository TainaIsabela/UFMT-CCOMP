// Implemente um método que produza uma tarefa que leia todas as palavras de um arquivo, tentando encontrar uma determinada palavra. Em seguida, para todos os arquivos em um diretório, escalone uma thread para executar a tarefa para cada arquivo. Interrompa todas as outras tarefas quando uma delas tiver sucesso (dica: use invokeAny()).

package Questao6;

public class Main {
    public static void main(String[] args) {
        String palavra = "java";
        String diretorio = "C:\\Users\\User\\Desktop\\";
        String arquivo = "arquivo.txt";

        Tarefa tarefa = new Tarefa(palavra, diretorio, arquivo);
        tarefa.start();

        System.out.println("Tarefa iniciada");

        try {
            tarefa.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
}