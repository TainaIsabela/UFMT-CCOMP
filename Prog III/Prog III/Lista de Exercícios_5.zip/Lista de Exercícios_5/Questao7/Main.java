// Escreva um programa que crie n threads, as quais devem executar tarefas que acumulam valores inteiros em uma variável compartilhada. A threa1 deve acumular 1 na variável compartilhada, a thread2 deve acumular 1+2, a thread3 deve acumular 1+2+3 e a threaN deve acumular 1+2+...+N na variável compartilhada. O acumulador deve ser declarado como public static long acc. Execute o programa várias vezes. Qual o valor do acumulador nas diferentes execuções? Por quê?

package Questao1.Questao7;

public class Main {

    public static class Thread1 extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < n; i++) {
                acc += i;
            }
        }
    }

    public static class Thread2 extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < n; i++) {
                acc += i;
            }
        }
    }

    public static class Thread3 extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < n; i++) {
                acc += i;
            }
        }
    }

    public static class ThreadN extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < n; i++) {
                acc += i;
            }
        }
    }

    public static long acc = 0;

    public static void main(String[] args) {
        int n = 10;
        for (int i = 0; i < n; i++) {
            new Thread1().start();
            new Thread2().start();
            new Thread3().start();
            new ThreadN().start();
        }
        System.out.println(acc);
    }


}