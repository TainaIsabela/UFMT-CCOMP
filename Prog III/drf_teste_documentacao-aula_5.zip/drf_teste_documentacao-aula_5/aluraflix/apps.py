from django.apps import AppConfig


class AluraflixConfig(AppConfig):
    name = 'aluraflix'
