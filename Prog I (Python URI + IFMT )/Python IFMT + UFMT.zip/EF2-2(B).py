print('Digite o número do somatório:')
som = int(input())
soma = 0
for i in range (som):
    soma = soma + i
print(soma)