

for i in range(0,127):
    print(" O caracter '%s' tem código ASCII %d"%(chr(i), i))