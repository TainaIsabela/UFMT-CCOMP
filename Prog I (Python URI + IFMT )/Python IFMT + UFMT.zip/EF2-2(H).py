print('Digite a temperatura em celsius:')
cel = float(input())
fah = (cel*9/5+32)
print ('Em fahrenheit:',fah)
