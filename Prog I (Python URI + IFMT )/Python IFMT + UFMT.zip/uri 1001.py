A = int(input())
B = int(input())

x = str (A + B)
print ('X = ' + str (x))
