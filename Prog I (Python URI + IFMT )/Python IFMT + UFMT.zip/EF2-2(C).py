print("Digite o valor: ")
valor = int(input())
a, b = 0, 1
while b < valor:
       print(b)
       a, b = b, a+b