print('Digite a cotação do real:')
cot= float(input())
print('Digite a quantidade de dólar disponível:')
real = float(input())
con = real*cot
print('O resultado da conversão: {:.2f}' .format(con), 'Reais')
