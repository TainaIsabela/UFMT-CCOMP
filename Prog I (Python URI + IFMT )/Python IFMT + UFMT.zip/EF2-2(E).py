print('Digite um número:')
num = int(input())
if num %2 == 0:
    print('par')
else:
    print('impar')