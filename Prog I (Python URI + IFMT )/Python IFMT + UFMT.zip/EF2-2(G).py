import math

print('Digite a, b e c:\nobs: com espaço de um enter entre eles')
a = int(input())
b = int(input())
c = int(input())
soma = a+b+c
print('O quadrado da soma é :' ,math.sqrt(soma))