lista = []
for i in range (0,10):
    lista.append(int(input()))
print('O maior número da lista é',min(lista))
print('O menor número da lista é',max(lista))