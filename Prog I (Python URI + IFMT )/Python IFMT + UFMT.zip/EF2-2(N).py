print('Digite seu nome:')
nome = input()
print('Seu sexo é masculino ou feminino?')
sexo = input()
if sexo == 'masculino':
    print('ilmo. Sr' ,nome)
if sexo == 'feminino':
    print('ilma.Sra', nome)