import math

print('Digite a, b e c:\nobs: com espaço de um enter entre eles')
a = int(input())
b = int(input())
c = int(input())
a = math.sqrt(a)
b = math.sqrt(b)
c=math.sqrt(c)
soma = a+b+c
print('A soma dos quadrados é :' ,soma)