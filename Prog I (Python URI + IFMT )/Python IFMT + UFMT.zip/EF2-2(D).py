print('Digite o número:')
num = int(input())
print('Digite o expoente:')
exp = int(input())


def potencia(num, exp):
    cal = num ** exp
    print(cal)


potencia(num, exp)
