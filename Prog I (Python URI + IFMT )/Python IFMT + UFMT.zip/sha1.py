import hashlib
resumo = hashlib.sha1('real programmers can write assembly code in any language. larry wall')
print(resumo.hexdigest())
