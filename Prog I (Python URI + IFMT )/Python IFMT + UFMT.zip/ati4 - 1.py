# -*- coding: utf-8 -*-
print('Digite o número que será exponenciado:')
num = int(input())
print('Digite o número que irá ser o expoente;')
exp = int(input())
res = num ** exp
print('A exponenciação equivale à: {}'.format(res))