print('Digite um valor:')
num = int(input())
if num % 2 == 0 or num % 3 == 0:
    print("Este valor é divisível por 2 ou por 3")
else:
    print('Valor invalido')