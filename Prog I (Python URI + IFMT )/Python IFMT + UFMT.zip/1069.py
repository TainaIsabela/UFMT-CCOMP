num = int(input())
dim = []
for i in range (num):
    dim[i]= str(input().split("."))
    for j in range (len(dim)):
        if dim[i] == "<" or ">":
            if dim[j] ==

            dim.pop()

