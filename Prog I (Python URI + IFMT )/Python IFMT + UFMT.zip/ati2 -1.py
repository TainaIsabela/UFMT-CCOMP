num1 = int(input())
num2 = int(input())
if num1<num2:
    print(num2, num1)
    print(num2, num1)
if num1==num2:
    print("São números iguais")
