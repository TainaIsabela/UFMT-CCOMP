for i in range(10):
    for j in range(10):
        if i > 0:
         print(i,"*",j+1,"=",i*(j+1) )
