print ("Digite o número de metros:")
met = float(input())
dec = met*10
cen = met*100
mil = met*1000

print("O correspondente em decímetros é: {}, em centímetros é: {}, e em milímetros é: {}" .format(dec, cen, mil))