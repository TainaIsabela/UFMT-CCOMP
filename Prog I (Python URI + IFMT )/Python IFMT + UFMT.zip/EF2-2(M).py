print('Digite um número:')
num = int(input())
print(abs(num))