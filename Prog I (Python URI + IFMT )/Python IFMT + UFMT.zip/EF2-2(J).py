print('Digite um valor:')
num = int(input())
if num % 2 == 0 and num % 3 == 0:
    print("Este valor é divisível por 2 e 3")
else:
    print('Valor invalido')