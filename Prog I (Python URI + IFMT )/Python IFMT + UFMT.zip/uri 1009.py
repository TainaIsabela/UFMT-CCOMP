nome =  (input())
salfi = float (input())
vendas = float (input())
comissao = (0.15*vendas)
salfin = (salfi+comissao)

print('TOTAL = R$ %0.2F' %salfin )