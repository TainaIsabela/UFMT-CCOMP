print("Digite os graus em Fahrenheit:")
fahi = int(input())
Celi = (fahi-32) * (5/9)
print("A temperatura em Celsius é %0.2f ºC" %Celi)