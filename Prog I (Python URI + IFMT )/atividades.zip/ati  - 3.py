print("Digite o número decimal:")
dec= int(input())
print("O correspodente Octal deste número é: {}, e o Hexadecimal é: {}".format(oct(dec), hex(dec)))