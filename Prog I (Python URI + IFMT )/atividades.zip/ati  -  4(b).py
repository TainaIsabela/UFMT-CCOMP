print("Digite os graus em Fahrenheit:")
fahb = float(input())
Celb= (fahb-32.0) * (5.0/9.0)
print("A temperatura em Celsius é %0.2f ºC" %Celb)