lista = []
for i in range (0,10):
    lista.append(int(input()))
print(sorted(lista))