nots = []

for i in range (0,5):
    nots.append(float(input()))

def notas(nots):

    print('Os números Digitados são:' ,nots.copy())

notas(nots)